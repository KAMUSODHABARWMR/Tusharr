import os

API_ID = os.environ.get("API_ID", "24473318") #Replace With your api id
API_HASH = os.environ.get("API_HASH", "e7dd0576c5ac0ff8f90971d6bb04c8f5") #Replace With your api hash
BOT_TOKEN = os.environ.get("BOT_TOKEN", "") #Replace With your bot token
